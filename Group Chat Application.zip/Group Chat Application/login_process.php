<?php 
	session_start();
	require_once("require/database_class.php");	
	$database = new Database(HOST_NAME,USER_NAME,PASSWORD,DATABASE);
	
	/*echo "<pre>";
	print_r($database->connection);*/

	if(isset($_POST['login'])){
		extract($_POST);
		

		$query = "SELECT * FROM users u ";
		$query .= "WHERE u.email ='{$email}' AND u.password ='{$password}' ";

		$result =  $database->execute_query($query);
		if($result->num_rows > 0){

			$row = mysqli_fetch_assoc($result);
			$_SESSION['user'] = $row;
			$query = "UPDATE users u SET is_online = '1' ";
			$query .= "WHERE u.user_id='".$row['user_id']."'";
			$database->execute_query($query);
			
			header("location:hist_chat_application.php");

		}else{
			header("location:index.php?msg=Invalid Email Or Password&color=red");
		}
	}
?>