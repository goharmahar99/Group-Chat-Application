<?php 
	define("HOST_NAME", "localhost");
	define("USER_NAME", "root");
	define("PASSWORD", "");
	define("DATABASE", "hist_chat_application");
?>