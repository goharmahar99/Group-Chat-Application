<?php 

	class Forms{
		public $action = NULL;
		public $method = "GET";

		public function set_action($_action){
			$this->action = $_action; 
		}

		public function get_action(){
			return $this->action; 
		}

		public function set_method($_method){
			$this->method = $_method; 
		}

		public function get_method(){
			return $this->method; 
		}

		public function login_form(){
		?>
		<div align="center">
		<fieldset style="width:80px;">
			<legend>Login Form</legend>
			<form action="<?= $this->get_action();?>" method="<?=  $this->method;  ?>" >
			<table>
				<tr>
					<td><b>Email:</b></td>
					<td>
						<input type="email" name="email" value="" />
					</td>
				</tr>
				<tr>
					<td><b>Password:</b></td>
					<td>
						<input type="password" name="password" value="" />
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<input style="padding: 5px;background-color: green;color:white;" type="submit" name="login" value="Login" />
						<input style="padding: 5px;background-color: red;color:white;" type="reset"  name="resert" value="reset" />
					</td>
				</tr>
			</table>	
			</form>
		</fieldset>
		</div>

		<?php	
		}


	}



?>